const API_URL = "http://localhost:3000/api/noticias";

export const obtenerNoticias = async () => {
  const response = await fetch(API_URL);

  if (!response.ok) {
    throw new Error("Error al obtener noticias");
  }

  return await response.json();
};